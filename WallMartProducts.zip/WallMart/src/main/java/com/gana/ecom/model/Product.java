package com.gana.ecom.model;

import java.util.Date;

public class Product {

	private int productId;
	private String ProductName;
	private String ProductPrice;
	/**
	 * @return the productId
	 */
	public int getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(int productId) {
		this.productId = productId;
	}
	/**
	 * @return the productName
	 */
	public String getProductName() {
		return ProductName;
	}
	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		ProductName = productName;
	}
	/**
	 * @return the productPrice
	 */
	public String getProductPrice() {
		return ProductPrice;
	}
	/**
	 * @param productPrice the productPrice to set
	 */
	public void setProductPrice(String productPrice) {
		ProductPrice = productPrice;
	}
	
	
}
