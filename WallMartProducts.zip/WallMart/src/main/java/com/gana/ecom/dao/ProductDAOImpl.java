package com.gana.ecom.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.gana.ecom.model.Employee;
import com.gana.ecom.model.Product;

@Repository
public class ProductDAOImpl implements ProductDAO {

	@Autowired
	private DataSource dataSource;

	public void addProduct(Product product) {
		try {
			PreparedStatement preparedStatement = dataSource.getConnection()
					.prepareStatement("insert into Products(ProductName,ProductPrice) values (?, ?)");
			// Parameters start with 1
			preparedStatement.setString(1, product.getProductName());
			preparedStatement.setString(2, product.getProductPrice());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public List<Product> getAllProducts() {
		List<Product> Products = new ArrayList<Product>();
		try {
			Statement statement =  dataSource.getConnection().createStatement();
			ResultSet rs = statement.executeQuery("select * from Products");
			while (rs.next()) {
				Product Product = new Product();
				Product.setProductId(rs.getInt("ProductId"));
				Product.setProductName(rs.getString("ProductName"));
				Product.setProductPrice(rs.getString("ProductPrice"));
				Products.add(Product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return Products;
	}

	@Override
	public void deleteProduct(Integer productId) {
		try {
			PreparedStatement preparedStatement = dataSource.getConnection()
					.prepareStatement("delete from Products where ProductId=?");
			// Parameters start with 1
			preparedStatement.setInt(1, productId);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Product getProduct(int productid) {
		Product product = new Product();
		try {
			PreparedStatement preparedStatement = dataSource.getConnection().
					prepareStatement("select * from Products where Productid=?");
			preparedStatement.setInt(1, productid);
			ResultSet rs = preparedStatement.executeQuery();
			
			if (rs.next()) {
				product.setProductId(rs.getInt("ProductId"));
				product.setProductName(rs.getString("ProductName"));
				product.setProductPrice(rs.getString("ProductPrice"));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return product;
	}

	@Override
	public void updateProduct(Product product) {
		try {
			PreparedStatement preparedStatement = dataSource.getConnection()
					.prepareStatement("update Products set ProductName=?, ProductPrice=? " +
							 "where ProductId=?");
			// Parameters start with 1
			preparedStatement.setString(1, product.getProductName());
		
			preparedStatement.setString(2, product.getProductPrice());
			preparedStatement.setInt(3, product.getProductId());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public Product getEmployee(int productid) {
		// TODO Auto-generated method stub
		return null;
	}

}