package com.gana.ecom.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.gana.ecom.model.Employee;
import com.gana.ecom.model.Product;
import com.gana.ecom.service.EmployeeService;
import com.gana.ecom.service.ProductService;

@Controller
@RequestMapping("/products")
public class ProductController {

	private static final Logger logger = Logger
			.getLogger(ProductController.class);

	public ProductController() {
		System.out.println("ProductController()");
	}

	@Autowired
	private ProductService productService;

	@RequestMapping(value = "/")
	public ModelAndView listProduct(ModelAndView model) throws IOException {
		List<Product> products = productService.getAllProducts();
		model.addObject("products", products);
		model.setViewName("home");
		return model;
	}

	@RequestMapping(value = "/newProduct", method = RequestMethod.GET)
	public ModelAndView newContact(ModelAndView model) {
		Product product = new Product();
		model.addObject("product", product);
		model.setViewName("ProductForm");
		return model;
	}

	@RequestMapping(value = "/saveProduct", method = RequestMethod.POST)
	public ModelAndView saveProduct(@ModelAttribute Product product) {
		if (product.getProductId() == 0) { // if product id is 0 then creating the
			// product other updating the product
			productService.addProduct(product);
		} else {
			productService.updateProduct(product);
		}
		return new ModelAndView("redirect:/");
	}

	@RequestMapping(value = "/deleteProduct", method = RequestMethod.GET)
	public ModelAndView deleteProduct(HttpServletRequest request) {
		int productId = Integer.parseInt(request.getParameter("id"));
		productService.deleteProduct(productId);
		return new ModelAndView("redirect:/");
	}

	@RequestMapping(value = "/editProduct", method = RequestMethod.GET)
	public ModelAndView editContact(HttpServletRequest request) {
		int productId = Integer.parseInt(request.getParameter("id"));
		Product product = productService.getProduct(productId);
		ModelAndView model = new ModelAndView("ProductForm");
		model.addObject("product", product);

		return model;
	}

}