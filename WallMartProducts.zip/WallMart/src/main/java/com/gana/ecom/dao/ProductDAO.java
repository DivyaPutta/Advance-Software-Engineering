package com.gana.ecom.dao;

import java.util.List;

import com.gana.ecom.model.Employee;
import com.gana.ecom.model.Product;

public interface ProductDAO {

	public void addProduct(Product product);

	public List<Product> getAllProducts();

	public void deleteProduct(Integer productId);

	public void updateProduct(Product product);

	public Product getProduct(int productid);

	public Product getEmployee(int productid);
}
